﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Education
{
    
    public class SchoolService : ISchoolService
    {
        
        public void DoWork()
        {
        }

        /*
        public StudentEntity getStudent(string studentId)
        {
            schoolEntities context = new schoolEntities();
            Int32 NstudentId = Convert.ToInt32(studentId);
            var data = context.students.Where(s => s.student_id == NstudentId).FirstOrDefault();
            StudentEntity stud = new StudentEntity();
            stud.StudentId = data.student_id;
            stud.StudentName = data.name;
            stud.Dob = DateTime.Parse(data.dob.ToString());
            return stud;
        }
        */

        public student getStudent(string studentId)
        {
            schoolEntities context = new schoolEntities();
            Int32 NstudentId = Convert.ToInt32(studentId);
            student data = context.students.Where(s => s.student_id == NstudentId).FirstOrDefault<student>();
            return data;
        }
    }
}
