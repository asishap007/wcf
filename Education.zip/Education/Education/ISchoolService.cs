﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;

namespace Education
{
    
    [ServiceContract]
    public interface ISchoolService
    {
        [OperationContract]
        void DoWork();

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Wrapped,Method ="GET",
            RequestFormat =WebMessageFormat.Json,
            ResponseFormat =WebMessageFormat.Json,
            UriTemplate = "/getStudent/{studentId}")]
        //StudentEntity getStudent(string studentId);
        student getStudent(string studentId);


    }

    [DataContract]
    public class StudentEntity
    {
        [DataMember]
        public int StudentId { get; set; }
        [DataMember]
        public string StudentName { get; set; }
        [DataMember]
        public DateTime Dob { get; set; }
    }
}
