﻿using GameReserveApp.Repository;
using GameReserveApp.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameReserveApp
{
    public partial class AddCategory : Form
    {
        public string categoryName;
        public string categoryColor;
        
        public AddCategory()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.categoryName = this.textBox1.Text;
            this.categoryColor = this.textBox2.Text;
        }
    }
}
