﻿using GameReserveApp.Repository;
using GameReserveApp.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameReserveApp
{
    public partial class AddAnimal : Form
    {
        public string categoryName;
        public string GPSDeviceId;
        public int categoryId;
        
        public AddAnimal()
        {
            InitializeComponent();
        }

        private void AddAnimal_Load(object sender, EventArgs e)
        {
            CategoryView[] category = CategoryRepository.GetAllCategories();
            this.comboBox1.DataSource = category;
            comboBox1.ValueMember = "id";
            comboBox1.DisplayMember = "CategoryName";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CategoryView selectedCategory = (CategoryView)this.comboBox1.Items[comboBox1.SelectedIndex];
            this.categoryId = selectedCategory.id;
            this.categoryName = selectedCategory.categoryName;
            this.GPSDeviceId = this.textBox1.Text;
        }
    }
}
