﻿using GameReserveApp.Repository;
using GameReserveApp.ViewModels;
using GMap.NET;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Xml;

namespace GameReserveApp
{
    public partial class LocateAnimals : Form
    {
        public LocateAnimals()
        {
            InitializeComponent();
        }

        private void LocateAnimals_Load(object sender, EventArgs e)
        {
          
        }

        /// <summary>
        /// Google map functionalities
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gMapControl_Load(object sender, EventArgs e)
        {
            this.loadMap();
        }

        private void LocateAnimals_Activated(object sender, EventArgs e)
        {
            this.loadMap();
        }

        private void loadMap()
        {
            try
            {
                //Loading the google map in the gmap control
                gMapControl.MapProvider = GMap.NET.MapProviders.BingMapProvider.Instance;
                GMap.NET.GMaps.Instance.Mode = GMap.NET.AccessMode.ServerOnly;
                gMapControl.Zoom = 3;
                gMapControl.Position = new PointLatLng(config.SALatitude, config.SALongitude);
                TrackingView[] points = TrackingRepository.GetLatestPositionOfAnimal();
                var lstTrackingByGroups = points.GroupBy(s => s.catId);
                GMarkerGoogle marker;
                GMapOverlay markersOverlay = new GMapOverlay("markers");
                int i = 0;
                foreach (var listByGroups in lstTrackingByGroups)
                {
                    foreach (TrackingView point in listByGroups)
                    {
                        point.colorIndication = config.CategoryColors[i];
                        GMarkerGoogleType MarkerColor = (GMarkerGoogleType)Enum.Parse(typeof(GMarkerGoogleType), point.colorIndication, true);
                        marker = new GMarkerGoogle(new PointLatLng(point.latitude, point.longitude), MarkerColor);
                        marker.ToolTipText = point.categoryName;
                        marker.ToolTipMode = MarkerTooltipMode.OnMouseOver;
                        markersOverlay.Markers.Add(marker);
                    }
                    i = i + 1;
                }
                gMapControl.Overlays.Add(markersOverlay);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

       
    }

}

