﻿using GameReserveService.ErrorHandler;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.ServiceModel.Web;
using System.Web;

namespace GameReserveService.Repository
{
    public class CategoryRepository
    {
        public static List<Category> categoryList()
        {
            List<Category> lstCategory = new List<Category>();
            using (game_reserveEntities context = new game_reserveEntities())
            {
                try
                {
                    var categories = from p in context.categories select p;
                    foreach (category singleCategory in categories)
                    {
                        Category cat = JsonConvert.DeserializeObject<Category>(JsonConvert.SerializeObject(singleCategory));
                        lstCategory.Add(cat);
                    }
                }
                catch (Exception ex)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", ex.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.NotFound);
                }

            }
            return lstCategory;
        }

        public static Category GetSingleCategory(string categoryId)
        {
            Int32 catId = Convert.ToInt32(categoryId);
            Category cat;
            using (game_reserveEntities context = new game_reserveEntities())
            {
                try
                {
                    var singleCategory = (from p in context.categories where p.id == catId select p).FirstOrDefault();
                    cat = JsonConvert.DeserializeObject<Category>(JsonConvert.SerializeObject(singleCategory));
                }
                catch (Exception ex)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", ex.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.BadRequest);
                }

            }
            return cat;
        }

        public static Category CreateNewCategory(Category categoryDetails)
        {
            string successMsg = "Created sucessfully";
            using (game_reserveEntities context = new game_reserveEntities())
            {
                category categoryEntity = JsonConvert.DeserializeObject<category>(JsonConvert.SerializeObject(categoryDetails));
                context.categories.Add(categoryEntity);
                try
                {
                    context.SaveChanges();
                    categoryDetails.id = categoryEntity.id;
                    categoryDetails.message = successMsg;
                    return categoryDetails;
                }
                catch (DbUpdateConcurrencyException Ex)
                {
                    Ex.Entries.Single().Reload();
                    context.SaveChanges();
                    categoryDetails.id = categoryEntity.id;
                    categoryDetails.message = successMsg;
                    return categoryDetails;
                }
                catch (Exception e)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", e.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.BadRequest);
                }

            }
        }


        public static Category UpdateSingleCategory(Category catgoryDetails)
        {
            using (game_reserveEntities context = new game_reserveEntities())
            {
                try
                {
                    category singleCategory = (from p in context.categories where p.id == catgoryDetails.id select p).FirstOrDefault<category>();
                    singleCategory.categoryName = catgoryDetails.categoryName;
                    singleCategory.colorIndication = catgoryDetails.colorIndication;
                    context.SaveChanges();
                    catgoryDetails.message = "Updated Successfully";
                    return catgoryDetails;
                }
                catch (Exception ex)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", ex.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.BadRequest);
                }

            }
        }


        public static Category DeleteCategory(string categoryId)
        {
            Int32 catId = Convert.ToInt32(categoryId);
            using (game_reserveEntities context = new game_reserveEntities())
            {
                try
                {
                    category singleCategory = (from p in context.categories where p.id == catId select p).FirstOrDefault<category>();
                    context.categories.Remove(singleCategory);
                    context.SaveChanges();
                    Category deletedCategory = JsonConvert.DeserializeObject<Category>(JsonConvert.SerializeObject(singleCategory));
                    deletedCategory.message = "Deleted successfully.";
                    return deletedCategory;
                }
                catch (Exception ex)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", ex.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.NotFound);
                }

            }
        }
        

    }
}