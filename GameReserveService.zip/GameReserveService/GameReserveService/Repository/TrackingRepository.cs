﻿using GameReserveService.ErrorHandler;
using GameReserveService.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.ServiceModel.Web;
using System.Web;

namespace GameReserveService.Repository
{
    public class TrackingRepository
    {
        

       

        public static GPSTracking AddTracking(GPSTracking GpsDetails)
        {
            string successMsg = "Created sucessfully";
            using (game_reserveEntities context = new game_reserveEntities())
            {
                var singleAnimal = (from p in context.animals where p.gpsDeviceId == GpsDetails.gpsDeviceId select p).FirstOrDefault();
                GpsDetails.animalId = singleAnimal.animalId;
                gpstracking trackingEntity = JsonConvert.DeserializeObject<gpstracking>(JsonConvert.SerializeObject(GpsDetails));
                trackingEntity.createdAt = DateTime.Now;
                context.gpstrackings.Add(trackingEntity);
                try
                {
                    context.SaveChanges();
                    GPSTracking castedGPSTracking = JsonConvert.DeserializeObject<GPSTracking>(JsonConvert.SerializeObject(trackingEntity, Formatting.None, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" }));
                    castedGPSTracking.message = successMsg;
                    return castedGPSTracking;
                }
                catch (DbUpdateConcurrencyException Ex)
                {
                    Ex.Entries.Single().Reload();
                    context.SaveChanges();
                    GPSTracking castedGPSTracking = JsonConvert.DeserializeObject<GPSTracking>(JsonConvert.SerializeObject(trackingEntity, Formatting.None, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" }));
                    castedGPSTracking.message = successMsg;
                    return castedGPSTracking;
                }
                catch (Exception e)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", e.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.BadRequest);
                }

            }
        }

        public static Animal UpdateAnimal(Animal animalDetails)
        {
            string successMsg = "Updated sucessfully";
            using (game_reserveEntities context = new game_reserveEntities())
            {
                animal singleAnimal = (from p in context.animals where p.animalId == animalDetails.animalId select p).FirstOrDefault<animal>();
                singleAnimal.categoryId = animalDetails.categoryId;
                singleAnimal.gpsDeviceId = animalDetails.gpsDeviceId;
                try
                {
                    context.SaveChanges();
                    Animal castedAnimal = JsonConvert.DeserializeObject<Animal>(JsonConvert.SerializeObject(singleAnimal, Formatting.None, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" }));
                    castedAnimal.message = successMsg;
                    return castedAnimal;
                }
                catch (DbUpdateConcurrencyException Ex)
                {
                    Ex.Entries.Single().Reload();
                    context.SaveChanges();
                    animalDetails.message = successMsg;
                    Animal castedAnimal = JsonConvert.DeserializeObject<Animal>(JsonConvert.SerializeObject(animalDetails, Formatting.None, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" }));
                    return castedAnimal;
                }
                catch (Exception e)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", e.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.BadRequest);
                }

            }
        }

        public static Animal DeleteAnimal(string animalId)
        {
            Int32 animId = Convert.ToInt32(animalId);
            using (game_reserveEntities context = new game_reserveEntities())
            {
                try
                {
                    animal singleAnimal = (from p in context.animals where p.animalId == animId select p).FirstOrDefault<animal>();
                    context.animals.Remove(singleAnimal);
                    context.SaveChanges();
                    Animal deletedAnimal = JsonConvert.DeserializeObject<Animal>(JsonConvert.SerializeObject(singleAnimal, Formatting.None, new IsoDateTimeConverter() { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" }));
                    deletedAnimal.message = "Deleted successfully.";
                    return deletedAnimal;
                }
                catch (Exception ex)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", ex.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.NotFound);
                }

            }
        }


        public static List<AnimalCategory> GetTotalCountOfAnimalsByCategory(string endDate)
        {
            string dt = (endDate == null) ? DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") : endDate;
            List<AnimalCategory> lstOfAnims = new List<AnimalCategory>();
            using (game_reserveEntities context = new game_reserveEntities())
            {
                try
                {
                    string sqlQuery = String.Format("SELECT category.id, category.colorIndication,category.categoryName, COUNT(*) as totalAnimals FROM animals INNER JOIN category ON category.id = animals.categoryId where animals.createdAt <= '{0}' GROUP BY category.id", dt);
                    lstOfAnims = context.Database.SqlQuery<AnimalCategory>(sqlQuery).ToList<AnimalCategory>();
                }
                catch (Exception ex)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", ex.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.NotFound);
                }

            }
            return lstOfAnims;
        }


        public static List <GPSTracking> GetLatestPositionOfAnimal()
        {
            List<GPSTracking> lstOfAnimsPos = new List<GPSTracking>();
            using (game_reserveEntities context = new game_reserveEntities())
            {
                try
                {
                    string sqlQuery = String.Format("SELECT cat.id as catId,cat.categoryName,cat.colorIndication,t.trackingId,t.createdAt,t.animalId,t.latitude,t.longitude,anim.gpsDeviceId FROM gpstracking AS t INNER JOIN animals AS anim ON t.animalId = anim.animalId INNER JOIN category as cat on cat.id = anim.categoryId  INNER JOIN ( SELECT trackingId, animalId, MAX( createdAt ) as MaxDate FROM gpstracking GROUP BY animalId) AS gp ON t.animalId = gp.animalId AND t.createdAt = gp.MaxDate");
                    lstOfAnimsPos = context.Database.SqlQuery<GPSTracking>(sqlQuery).ToList<GPSTracking>();
                }
                catch (Exception ex)
                {
                    ServiceErrorHandler customError = new ServiceErrorHandler("DB error", ex.Message);
                    throw new WebFaultException<ServiceErrorHandler>(customError, HttpStatusCode.NotFound);
                }
            }
            return lstOfAnimsPos;
        }

        
        

    }
}