﻿using GameReserveService.ErrorHandler;
using GameReserveService.Helper;
using GameReserveService.Repository;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace GameReserveService
{
    public class CategoryService : ICategoryService
    {
        
        public List<Category> GetAllCategories()
        {
            return CategoryRepository.categoryList();
        }

        public Category GetCategory(string categoryId)
        {
            return CategoryRepository.GetSingleCategory(categoryId);
        }

        public Category SaveCategory(Category categoryDetails)
        {
            return CategoryRepository.CreateNewCategory(categoryDetails);
        }

        public Category UpdateCategory(Category cat)
        {
            return CategoryRepository.UpdateSingleCategory(cat);
        }

        public Category DeleteCategory(string categoryId)
        {
            return CategoryRepository.DeleteCategory(categoryId);
        }


    }
}
