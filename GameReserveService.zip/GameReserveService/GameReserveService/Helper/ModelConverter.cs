﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace GameReserveService.Helper
{
    public class ModelConverter
    {
        public static K DeSerializeObject<K>(string jsonString){
            var deserializedOutput = JsonConvert.DeserializeObject<K>(jsonString);
            return (K)Convert.ChangeType(deserializedOutput, typeof(K));
        }

    }
}