﻿using GameReserveService.Models;
using GameReserveService.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace GameReserveService
{
    
    public class AnimalService : IAnimalService
    {

        public Animal AddAnimal(Animal request)
        {
           return AnimalRepository.AddNewAnimal(request);
        }

        public Animal UpdateAnimal(Animal animalDetails)
        {
            return AnimalRepository.UpdateAnimal(animalDetails);
        }

        public Animal DeleteCategory(string animalId)
        {
            return AnimalRepository.DeleteAnimal(animalId);
        }

        public List<Animal> GetAllAnimals()
        {
            return AnimalRepository.AnimalList();
        }

        public List<AnimalCategory> GetTotalCountOfAnimalsByCategory(string endDate, string fromDate)
        {
            return AnimalRepository.GetTotalCountOfAnimalsByCategory(endDate, fromDate);
        }
    }
}
