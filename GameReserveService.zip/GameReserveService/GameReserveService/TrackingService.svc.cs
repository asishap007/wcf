﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using GameReserveService.Models;
using GameReserveService.Repository;

namespace GameReserveService
{
    
    public class TrackingService : ITrackingService
    {
        public GPSTracking AddTracking(GPSTracking gpsDetails)
        {
            return TrackingRepository.AddTracking(gpsDetails);
        }

        public List<GPSTracking> GetLatestPositionOfAnimal()
        {
            return TrackingRepository.GetLatestPositionOfAnimal();
        }
    }
}
